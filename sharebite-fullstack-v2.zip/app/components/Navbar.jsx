"use client";
import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { HandPlatter } from 'lucide-react';

export default function Navbar() {
  const { data: session } = useSession();

  return (
    <header className="bg-white/80 backdrop-blur-md border-b px-4 py-4 sticky top-0 z-50 transition-all">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        <Link href="/" className="font-extrabold text-2xl text-orange-600 tracking-tight flex items-center gap-2">
          <HandPlatter className="w-7 h-7" /> ShareBite
        </Link>
        <nav className="flex gap-4 md:gap-6 items-center">
          <Link href="/dashboard" className="text-gray-700 font-bold hover:text-orange-600 transition">Feed</Link>
          {session ? (
            <>
              {session.user.role === 'DONOR' && (
                <Link href="/donate" className="text-gray-700 font-bold hover:text-orange-600 transition">Donate</Link>
              )}
              {session.user.role === 'ADMIN' && (
                <Link href="/admin" className="text-indigo-600 font-bold hover:text-indigo-800 transition">Admin</Link>
              )}
              <div className="h-6 w-px bg-gray-300 hidden md:block"></div>
              <button 
                onClick={() => signOut({ callbackUrl: '/' })} 
                className="text-sm font-bold bg-gray-100 text-gray-700 px-4 py-2 rounded-full hover:bg-gray-200 transition">
                Logout
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm font-bold text-gray-700 hover:text-orange-600 transition">Log In</Link>
              <Link href="/register" className="text-sm font-bold bg-orange-600 text-white px-5 py-2.5 rounded-full hover:bg-orange-700 transition shadow-md shadow-orange-200">Sign Up</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
