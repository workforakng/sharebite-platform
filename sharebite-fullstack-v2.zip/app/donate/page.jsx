"use client";
import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Utensils, CalendarClock, MapPin, AlignLeft, Info } from 'lucide-react';

export default function Donate() {
  const { data: session } = useSession();
  const router = useRouter();
  const [formData, setFormData] = useState({ 
    title: '', type: 'Cooked Meals', quantity: '', 
    expires: '', pickupStart: '', pickupEnd: '', 
    location: '', notes: '' 
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await fetch('/api/donations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    router.push('/dashboard');
    router.refresh();
  };

  return (
    <div className="max-w-3xl mx-auto bg-white p-8 md:p-12 rounded-[2rem] shadow-sm border border-gray-100 mt-8 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-400 to-orange-600"></div>

      <div className="mb-10">
        <h1 className="text-4xl font-extrabold text-gray-900 mb-3 tracking-tight">List Food</h1>
        <p className="text-gray-500 font-medium text-lg">Help NGOs and volunteers rescue your surplus food efficiently.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic Info */}
        <section className="space-y-5">
          <div className="flex items-center gap-2 text-orange-600 font-bold uppercase tracking-widest text-xs mb-2">
            <Utensils className="w-4 h-4" /> Food Details
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Donation Title</label>
            <input type="text" placeholder="e.g. 5 Trays of Buffet Sandwiches" required 
              className="w-full border-2 border-gray-200 p-4 rounded-xl focus:border-orange-500 focus:ring-0 outline-none transition" 
              onChange={e => setFormData({...formData, title: e.target.value})} />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Category</label>
              <select className="w-full border-2 border-gray-200 p-4 rounded-xl focus:border-orange-500 outline-none transition bg-white" 
                onChange={e => setFormData({...formData, type: e.target.value})}>
                <option>Cooked Meals</option>
                <option>Raw Ingredients/Produce</option>
                <option>Packaged Items</option>
                <option>Bakery/Bread</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Quantity</label>
              <input type="text" placeholder="e.g. 50 servings, 10 kg" required 
                className="w-full border-2 border-gray-200 p-4 rounded-xl focus:border-orange-500 outline-none transition" 
                onChange={e => setFormData({...formData, quantity: e.target.value})} />
            </div>
          </div>
        </section>

        {/* Timing */}
        <section className="space-y-5 bg-gray-50 p-6 rounded-2xl border border-gray-100">
          <div className="flex items-center gap-2 text-orange-600 font-bold uppercase tracking-widest text-xs mb-2">
            <CalendarClock className="w-4 h-4" /> Scheduling
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Absolute Expiration Time</label>
            <input type="datetime-local" required 
              className="w-full border-2 border-gray-200 p-4 rounded-xl focus:border-orange-500 outline-none transition bg-white" 
              onChange={e => setFormData({...formData, expires: e.target.value})} />
            <p className="text-xs text-gray-500 mt-2 flex items-center gap-1"><Info className="w-3 h-3"/> Food will be marked unsafe after this time.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Pickup Window Start (Opt)</label>
              <input type="datetime-local" 
                className="w-full border-2 border-gray-200 p-4 rounded-xl focus:border-orange-500 outline-none transition bg-white" 
                onChange={e => setFormData({...formData, pickupStart: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Pickup Window End (Opt)</label>
              <input type="datetime-local" 
                className="w-full border-2 border-gray-200 p-4 rounded-xl focus:border-orange-500 outline-none transition bg-white" 
                onChange={e => setFormData({...formData, pickupEnd: e.target.value})} />
            </div>
          </div>
        </section>

        {/* Location & Extra */}
        <section className="space-y-5">
          <div className="flex items-center gap-2 text-orange-600 font-bold uppercase tracking-widest text-xs mb-2 mt-4">
            <MapPin className="w-4 h-4" /> Logistics
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Exact Pickup Address</label>
            <input type="text" placeholder="123 Main St, Back Alley Door" required 
              className="w-full border-2 border-gray-200 p-4 rounded-xl focus:border-orange-500 outline-none transition" 
              onChange={e => setFormData({...formData, location: e.target.value})} />
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Instructions / Notes</label>
            <textarea placeholder="e.g. Ring the bell, bring your own containers, contains nuts..." 
              className="w-full border-2 border-gray-200 p-4 rounded-xl focus:border-orange-500 outline-none transition min-h-32" 
              onChange={e => setFormData({...formData, notes: e.target.value})} />
          </div>
        </section>

        <button disabled={loading} className="w-full bg-orange-600 text-white py-5 rounded-xl font-bold text-lg hover:bg-orange-700 transition transform hover:-translate-y-1 shadow-lg shadow-orange-200 disabled:opacity-60 disabled:transform-none mt-4">
          {loading ? 'Publishing to Network...' : 'Publish Food Donation'}
        </button>
      </form>
    </div>
  );
}
