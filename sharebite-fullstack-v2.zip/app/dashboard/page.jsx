"use client";
import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { MapPin, Clock, Package, User, CheckCircle2, Navigation } from 'lucide-react';

export default function Dashboard() {
  const { data: session } = useSession();
  const [donations, setDonations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('ALL'); // ALL, MY_CLAIMS, MY_DONATIONS

  const loadDonations = async () => {
    setLoading(true);
    const res = await fetch('/api/donations', { cache: 'no-store' });
    const data = await res.json();
    setDonations(data);
    setLoading(false);
  };

  useEffect(() => { loadDonations(); }, []);

  const handleClaim = async (id) => {
    if (!session) return alert('Please login to claim food.');
    if (!confirm('Commit to collecting this donation?')) return;

    const res = await fetch(`/api/donations/${id}/claim`, { method: 'POST' });
    if (!res.ok) {
      const data = await res.json();
      alert(data.error);
    } else {
      loadDonations();
    }
  };

  const handleStatus = async (id, newStatus) => {
    await fetch(`/api/donations/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });
    loadDonations();
  };

  const filtered = donations.filter(d => {
    if (filter === 'MY_CLAIMS') return d.claimerId === session?.user?.id;
    if (filter === 'MY_DONATIONS') return d.donorId === session?.user?.id;
    return d.status === 'AVAILABLE';
  });

  return (
    <div className="mt-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight">Rescue Feed</h1>
          <p className="text-gray-500 mt-2 font-medium">Real-time surplus food availability in your area.</p>
        </div>

        <div className="flex gap-2 bg-gray-100 p-1 rounded-xl w-full md:w-auto">
          <button onClick={() => setFilter('ALL')} className={`px-4 py-2 rounded-lg font-bold text-sm transition flex-1 ${filter === 'ALL' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>Available</button>
          {session?.user?.role !== 'DONOR' && (
            <button onClick={() => setFilter('MY_CLAIMS')} className={`px-4 py-2 rounded-lg font-bold text-sm transition flex-1 ${filter === 'MY_CLAIMS' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>My Claims</button>
          )}
          {session?.user?.role === 'DONOR' && (
            <button onClick={() => setFilter('MY_DONATIONS')} className={`px-4 py-2 rounded-lg font-bold text-sm transition flex-1 ${filter === 'MY_DONATIONS' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>My Donations</button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="text-center py-20 text-gray-400 font-semibold animate-pulse">Scanning area for donations...</div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filtered.map(d => (
            <div key={d.id} className="group bg-white rounded-3xl p-6 shadow-sm border border-gray-100 hover:border-orange-200 hover:shadow-md transition-all">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-orange-50 text-orange-700 rounded-lg text-xs font-bold uppercase tracking-wider">{d.type}</span>
                  {d.status === 'CLAIMED' && <span className="px-3 py-1 bg-blue-50 text-blue-700 rounded-lg text-xs font-bold uppercase tracking-wider">Claimed</span>}
                  {d.status === 'COLLECTED' && <span className="px-3 py-1 bg-green-50 text-green-700 rounded-lg text-xs font-bold uppercase tracking-wider">Collected</span>}
                </div>
                <span className="text-xs text-gray-400 font-semibold">{new Date(d.createdAt).toLocaleDateString()}</span>
              </div>

              <h3 className="text-2xl font-extrabold text-gray-900 mb-5">{d.title}</h3>

              <div className="space-y-3 mb-6 bg-gray-50 p-4 rounded-2xl">
                <div className="flex items-start gap-3 text-gray-700 text-sm">
                  <Package className="w-5 h-5 text-gray-400 shrink-0" />
                  <span className="font-semibold">{d.quantity}</span>
                </div>
                <div className="flex items-start gap-3 text-gray-700 text-sm">
                  <User className="w-5 h-5 text-gray-400 shrink-0" />
                  <span>{d.donor?.name}</span>
                </div>
                <div className="flex items-start gap-3 text-gray-700 text-sm">
                  <Clock className="w-5 h-5 text-gray-400 shrink-0" />
                  <div>
                    <span className="font-semibold text-red-600">Expires: {new Date(d.expires).toLocaleString([], {weekday:'short', hour:'2-digit', minute:'2-digit'})}</span>
                    {(d.pickupStart && d.pickupEnd) && (
                      <div className="text-xs text-gray-500 mt-0.5">Pickup window: {new Date(d.pickupStart).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})} - {new Date(d.pickupEnd).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</div>
                    )}
                  </div>
                </div>
                <div className="flex items-start gap-3 text-gray-700 text-sm">
                  <MapPin className="w-5 h-5 text-gray-400 shrink-0" />
                  <div className="flex items-center gap-2">
                    <span>{d.location}</span>
                    <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(d.location)}`} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:text-blue-700" title="Open in Map">
                      <Navigation className="w-4 h-4" />
                    </a>
                  </div>
                </div>
                {d.notes && (
                  <div className="text-sm text-gray-500 italic border-t pt-3 mt-3">"{d.notes}"</div>
                )}
              </div>

              {d.status === 'AVAILABLE' && session?.user?.role !== 'DONOR' && (
                <button onClick={() => handleClaim(d.id)} className="w-full flex items-center justify-center gap-2 bg-gray-900 text-white py-4 rounded-xl font-bold hover:bg-orange-600 transition shadow-md">
                  <CheckCircle2 className="w-5 h-5" />
                  Commit to Rescue
                </button>
              )}

              {d.status === 'CLAIMED' && (d.claimerId === session?.user?.id || d.donorId === session?.user?.id) && (
                <button onClick={() => handleStatus(d.id, 'COLLECTED')} className="w-full flex items-center justify-center gap-2 bg-green-600 text-white py-4 rounded-xl font-bold hover:bg-green-700 transition shadow-md">
                  Mark as Collected
                </button>
              )}
            </div>
          ))}
          {filtered.length === 0 && (
             <div className="col-span-full py-24 text-center border-2 border-dashed border-gray-200 rounded-3xl">
               <div className="text-5xl mb-4">🌍</div>
               <h3 className="text-xl font-bold text-gray-800 mb-2">No donations found</h3>
               <p className="text-gray-500">Check back later or adjust your filters.</p>
             </div>
          )}
        </div>
      )}
    </div>
  );
}
