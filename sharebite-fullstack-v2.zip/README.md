# ShareBite - Production Ready Fullstack App

ShareBite is a fullstack food rescue platform built with Next.js 14, Prisma, PostgreSQL, NextAuth, and Tailwind CSS. It connects food donors with NGOs, shelters, and volunteers who can claim and collect surplus food before it goes to waste.

## Production stack
- Next.js 14 App Router
- PostgreSQL database via Prisma
- NextAuth credentials authentication
- Bcrypt password hashing
- Tailwind CSS UI
- Vercel-ready deployment config

## Main features
- Donor, NGO, and Volunteer roles
- Secure registration and login
- Donor-only food listing flow
- Live rescue dashboard
- Claim workflow for NGOs and volunteers
- Protected donate route

## Repo structure
- `app/` - frontend pages and API routes
- `lib/prisma.js` - Prisma client singleton
- `prisma/schema.prisma` - database schema
- `middleware.js` - route protection
- `vercel.json` - production build config
- `.env.example` - required environment variables

## Local setup
1. Install dependencies
```bash
npm install
```
2. Create `.env` from `.env.example`
3. Add a PostgreSQL `DATABASE_URL`
4. Push the schema
```bash
npx prisma db push
```
5. Run locally
```bash
npm run dev
```

## Vercel deployment
1. Create a PostgreSQL database with Neon, Supabase, Railway, or Vercel Postgres.
2. Add these environment variables in Vercel:
   - `DATABASE_URL`
   - `NEXTAUTH_SECRET`
   - `NEXTAUTH_URL`
3. Push this repo to GitHub.
4. Import the repo into Vercel.
5. Deploy. The included `vercel.json` runs `npx prisma db push && npm run build` during build.

## Required environment variables
```env
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME?sslmode=require
NEXTAUTH_SECRET=replace-with-a-long-random-secret
NEXTAUTH_URL=https://your-app.vercel.app
```

## Important
SQLite is not suitable for production on Vercel because Vercel serverless storage is ephemeral. This project is configured for PostgreSQL so it can run in production correctly on Vercel.
