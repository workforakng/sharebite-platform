import { prisma } from "../../../../../lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "../../auth/[...nextauth]/route";

export async function POST(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (session.user.role === "DONOR") return NextResponse.json({ error: "Donors cannot claim food" }, { status: 403 });

  const { id } = params;
  const updated = await prisma.donation.update({
    where: { id },
    data: { status: "CLAIMED", claimerId: session.user.id }
  });
  return NextResponse.json(updated);
}
