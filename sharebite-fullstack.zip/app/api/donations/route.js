import { prisma } from "../../../lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "../auth/[...nextauth]/route";

export const dynamic = 'force-dynamic';

export async function GET() {
  const donations = await prisma.donation.findMany({
    include: { donor: { select: { name: true } }, claimer: { select: { name: true } } },
    orderBy: { createdAt: 'desc' }
  });
  return NextResponse.json(donations);
}

export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const data = await req.json();

  const donation = await prisma.donation.create({
    data: {
      title: data.title,
      type: data.type,
      quantity: data.quantity,
      expires: new Date(data.expires),
      location: data.location,
      donorId: session.user.id
    }
  });
  return NextResponse.json(donation, { status: 201 });
}
