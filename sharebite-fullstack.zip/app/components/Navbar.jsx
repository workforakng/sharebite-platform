"use client";
import Link from "next/link";
import { useSession, signOut } from "next-auth/react";

export default function Navbar() {
  const { data: session } = useSession();

  return (
    <header className="bg-white border-b px-4 py-4 mb-6 shadow-sm sticky top-0 z-50">
      <div className="max-w-5xl mx-auto flex justify-between items-center">
        <Link href="/" className="font-extrabold text-2xl text-orange-600 tracking-tight">ShareBite</Link>
        <nav className="flex gap-5 items-center">
          <Link href="/dashboard" className="text-gray-700 font-medium hover:text-orange-600">Feed</Link>
          {session ? (
            <>
              {session.user.role === 'DONOR' && (
                <Link href="/donate" className="text-gray-700 font-medium hover:text-orange-600">Donate Food</Link>
              )}
              <button 
                onClick={() => signOut({ callbackUrl: '/' })} 
                className="text-sm font-semibold bg-gray-100 px-4 py-2 rounded-full hover:bg-gray-200 transition">
                Logout ({session.user.name})
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm font-semibold text-gray-700 hover:text-orange-600">Login</Link>
              <Link href="/register" className="text-sm font-bold bg-orange-600 text-white px-5 py-2 rounded-full hover:bg-orange-700 transition transform hover:-translate-y-0.5 shadow-md">Sign Up</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
