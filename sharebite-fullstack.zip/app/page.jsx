export default function Home() {
  return (
    <div className="text-center py-20">
      <h1 className="text-5xl md:text-6xl font-extrabold mb-6 text-gray-900 leading-tight">
        Zero Food Waste. <br/><span className="text-orange-600">Zero Hunger.</span>
      </h1>
      <p className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto leading-relaxed">
        Connect surplus food from restaurants, events, and households directly to NGOs and volunteers who can distribute it to those in need.
      </p>
      <div className="flex justify-center gap-4 flex-wrap">
        <a href="/register?role=DONOR" className="bg-orange-600 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-orange-700 shadow-lg transition transform hover:-translate-y-1">
          I Have Food to Donate
        </a>
        <a href="/register?role=NGO" className="bg-green-700 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-green-800 shadow-lg transition transform hover:-translate-y-1">
          I Want to Rescue Food
        </a>
      </div>

      <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
        <div className="bg-white p-6 rounded-2xl shadow-sm border">
          <div className="text-4xl mb-4">🍽️</div>
          <h3 className="font-bold text-xl mb-2">1. List Surplus</h3>
          <p className="text-gray-600">Donors easily post details about their excess edible food, including pickup times.</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border">
          <div className="text-4xl mb-4">🔔</div>
          <h3 className="font-bold text-xl mb-2">2. Live Alerts</h3>
          <p className="text-gray-600">Verified NGOs and volunteers see the live dashboard feed of available rescues.</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border">
          <div className="text-4xl mb-4">🚚</div>
          <h3 className="font-bold text-xl mb-2">3. Claim & Collect</h3>
          <p className="text-gray-600">Volunteers claim the food online and pick it up before it goes to waste.</p>
        </div>
      </div>
    </div>
  );
}
