"use client";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function Donate() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [formData, setFormData] = useState({ title: "", type: "Cooked Meals", quantity: "", expires: "", location: "" });
  const [loading, setLoading] = useState(false);

  // Protected route logic
  if (status === "loading") return <div className="text-center mt-20">Loading...</div>;
  if (status === "unauthenticated") { router.push("/login"); return null; }
  if (session?.user?.role !== "DONOR") return <div className="text-center mt-20 p-10 bg-white rounded-lg">Only Donor accounts can list food.</div>;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await fetch("/api/donations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData)
    });
    router.push("/dashboard");
  };

  return (
    <div className="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-sm border mt-8">
      <h1 className="text-3xl font-extrabold mb-2">List Surplus Food</h1>
      <p className="text-gray-600 mb-8">Details will immediately be shared to the live rescue feed.</p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">What are you donating?</label>
          <input type="text" placeholder="e.g. 10 Trays of Lasagna, 5kg Fresh Tomatoes" required className="w-full border p-3 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none" onChange={e => setFormData({...formData, title: e.target.value})} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Food Category</label>
            <select className="w-full border p-3 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none bg-white" onChange={e => setFormData({...formData, type: e.target.value})}>
              <option>Cooked Meals</option>
              <option>Raw Ingredients/Produce</option>
              <option>Packaged Items</option>
              <option>Bakery/Bread</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Quantity</label>
            <input type="text" placeholder="e.g. 20 servings, 3 boxes" required className="w-full border p-3 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none" onChange={e => setFormData({...formData, quantity: e.target.value})} />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">Expiration / Must Pickup By</label>
          <input type="datetime-local" required className="w-full border p-3 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none" onChange={e => setFormData({...formData, expires: e.target.value})} />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">Pickup Location (Address or Details)</label>
          <input type="text" placeholder="e.g. Back door of 123 Main St, ring bell" required className="w-full border p-3 rounded-lg focus:ring-2 focus:ring-orange-500 focus:outline-none" onChange={e => setFormData({...formData, location: e.target.value})} />
        </div>

        <button disabled={loading} className="w-full bg-orange-600 text-white p-4 rounded-lg font-bold text-lg hover:bg-orange-700 mt-4 transition shadow-md">
          {loading ? 'Posting...' : 'Post Donation to Feed'}
        </button>
      </form>
    </div>
  );
}
