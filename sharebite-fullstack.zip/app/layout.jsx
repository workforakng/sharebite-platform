import './globals.css';
import Navbar from './components/Navbar';
import AuthProvider from './components/AuthProvider';

export const metadata = {
  title: 'ShareBite | Food Rescue',
  description: 'Production-ready food rescue platform.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="text-gray-900 font-sans min-h-screen flex flex-col">
        <AuthProvider>
          <Navbar />
          <main className="max-w-5xl mx-auto w-full p-4 flex-grow">{children}</main>
          <footer className="bg-gray-100 text-center py-6 mt-12 text-sm text-gray-500 border-t">
            &copy; 2026 ShareBite Platform.
          </footer>
        </AuthProvider>
      </body>
    </html>
  );
}
