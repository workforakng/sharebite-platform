"use client";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";

export default function Dashboard() {
  const { data: session } = useSession();
  const [donations, setDonations] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadDonations = async () => {
    const res = await fetch("/api/donations");
    const data = await res.json();
    setDonations(data);
    setLoading(false);
  };

  useEffect(() => { loadDonations(); }, []);

  const handleClaim = async (id) => {
    if (!session) return alert("Please login as an NGO or Volunteer to claim food.");
    if (session.user.role === "DONOR") return alert("Donors cannot claim food. Login as NGO/Volunteer.");

    if (confirm("Are you sure you can pick this up before it expires?")) {
      await fetch(`/api/donations/${id}/claim`, { method: "POST" });
      loadDonations();
    }
  };

  return (
    <div className="mt-4">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-extrabold">Live Rescue Feed</h1>
          <p className="text-gray-600 mt-1">Real-time availability of surplus food near you.</p>
        </div>
        <button onClick={loadDonations} className="bg-white border text-gray-700 px-4 py-2 rounded-lg font-semibold hover:bg-gray-50 transition shadow-sm">
          ↻ Refresh
        </button>
      </div>

      {loading ? (
        <div className="text-center py-20 text-gray-500 font-medium">Loading food feed...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {donations.map(d => (
            <div key={d.id} className={`flex flex-col p-6 rounded-2xl shadow-sm border transition ${d.status === 'CLAIMED' ? 'bg-gray-50 border-gray-200' : 'bg-white hover:shadow-md'}`}>
              <div className="flex justify-between items-start mb-3">
                <span className="text-xs font-bold px-3 py-1 bg-orange-100 text-orange-800 rounded-full tracking-wide uppercase">{d.type}</span>
                {d.status === 'CLAIMED' && <span className="text-xs font-bold px-3 py-1 bg-gray-200 text-gray-600 rounded-full">Claimed</span>}
              </div>

              <h3 className={`font-extrabold text-xl mb-3 ${d.status === 'CLAIMED' ? 'text-gray-500' : 'text-gray-900'}`}>{d.title}</h3>

              <div className="flex-grow flex flex-col gap-2 text-sm text-gray-600 mb-6">
                <p><span className="font-semibold text-gray-800">Quantity:</span> {d.quantity}</p>
                <p><span className="font-semibold text-gray-800">Donor:</span> {d.donor?.name}</p>
                <p><span className="font-semibold text-gray-800">Location:</span> {d.location}</p>
                <p className={`font-bold ${new Date(d.expires) < new Date() ? 'text-red-600' : 'text-green-700'}`}>
                  Expires: {new Date(d.expires).toLocaleString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute:'2-digit'})}
                </p>
              </div>

              {d.status === 'AVAILABLE' ? (
                <button 
                  onClick={() => handleClaim(d.id)} 
                  className="w-full bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700 transition shadow-sm">
                  Claim & Rescue
                </button>
              ) : (
                <div className="w-full bg-gray-100 text-gray-500 py-3 rounded-lg font-bold text-center border">
                  Claimed by {d.claimer?.name}
                </div>
              )}
            </div>
          ))}
          {donations.length === 0 && (
            <div className="col-span-full text-center py-16 bg-white rounded-2xl border border-dashed">
              <p className="text-gray-500 font-medium">No food available for rescue right now. Check back soon!</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
