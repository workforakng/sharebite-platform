# ShareBite - Fullstack Production Build

ShareBite is a fullstack food rescue platform built with **Next.js 14 (App Router)**, **NextAuth.js**, **Prisma ORM**, and **Tailwind CSS**. It connects food donors with NGOs and volunteers.

## Features
- **User Authentication**: Secure login and registration with Bcrypt hashing.
- **Role-Based Access**: 
  - `DONOR`: Can post food donations.
  - `NGO` / `VOLUNTEER`: Can view the feed and claim food.
- **Live Database**: Data is saved and retrieved from a real SQL database.
- **REST API Routes**: Fully functional backend built directly into Next.js.

## Local Development (Runs Out of the Box!)

We have configured the project to use a local **SQLite database** (`dev.db`) by default so you can test it immediately without complex database setup.

1. **Install Dependencies**
   ```bash
   npm install
   ```
2. **Initialize Database** (Creates `dev.db` locally based on Prisma schema)
   ```bash
   npx prisma db push
   ```
3. **Run the Application**
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

## Deploying to Vercel (Production)

Vercel's serverless environment does not support SQLite file-based databases because the filesystem is ephemeral. To deploy:

1. **Set up a PostgreSQL Database**: Create a free PostgreSQL database on [Supabase](https://supabase.com), [Neon](https://neon.tech), or Vercel Storage.
2. **Update Prisma Schema**:
   Open `prisma/schema.prisma` and change the provider from `"sqlite"` to `"postgresql"`.
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```
3. **Push to GitHub**: Commit your code and push it to a new GitHub repository.
4. **Deploy on Vercel**: 
   - Import your GitHub repo into Vercel.
   - In the **Environment Variables** section, add:
     - `DATABASE_URL` (Your PostgreSQL connection string)
     - `NEXTAUTH_SECRET` (A random generated string, e.g. run `openssl rand -base64 32`)
     - `NEXTAUTH_URL` (Your Vercel deployment URL, e.g. `https://sharebite.vercel.app`)
5. **Run Migrations on Deploy**:
   In your Vercel project settings, set the **Build Command** to:
   ```bash
   npx prisma db push && npm run build
   ```
6. **Deploy!**
